﻿using Base.Data;
using Component.Entities;

using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Base.Repositories
{
        public class AppRepository
        {
            private readonly DbContext _db;

            public AppRepository(DbContext db)
            {
                _db = db;
            }

            public async Task<List<Note>> GetAsync()
            {
                return await _db.Set<Note>()
                    .OrderByDescending(n => n.CreatedAt)
                    .ToListAsync();
            }
            public async Task AddAsync(Note note)
            {
                _db.Set<Note>().Add(note);
                await _db.SaveChangesAsync();
            }

            public async Task UpdateAsync(Note note)
            {
                note.UpdatedAt = DateTime.UtcNow;
                _db.Set<Note>().Update(note);
                await _db.SaveChangesAsync();
            }

            public async Task DeleteAsync(int id)
            {
                var note = await _db.Set<Note>().FindAsync(id);
                if (note != null)
                {
                    _db.Set<Note>().Remove(note);
                    await _db.SaveChangesAsync();
                }
            }
        }
    }
