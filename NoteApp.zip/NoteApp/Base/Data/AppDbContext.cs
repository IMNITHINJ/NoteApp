﻿using Component.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Base.Data
{
    // Rename this class to avoid circular base type dependency with Microsoft.EntityFrameworkCore.DbContext
    public class AppDbContext : DbContext
    {
        public DbSet<Note> notes => Set<Note>();

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) 
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Note>().Property(n=>n.Title).IsRequired();

            modelBuilder.Entity<Note>().Property(n=>n.Content).IsRequired();
        }

    }
}
