﻿namespace Component
{
    public class Class1
    {

    }
}
