﻿using Component.Entities;
using Microsoft.AspNetCore.Mvc;
using Base.Repositories;

namespace NotesApplication.Controllers
{
    public class NoteController : Controller
    {
        private readonly AppRepository _repo;

        public NoteController(AppRepository repo)
        {
            _repo = repo;
        }

        public async Task<IActionResult> Index()
        {
            var notes = await _repo.GetAsync();
            return View(notes);
        }

        [HttpPost]
        public async Task<IActionResult> Create(Note note)
        {
            if (!ModelState.IsValid)
                return RedirectToAction("Index");

            await _repo.AddAsync(note);
            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> Update(Note note)
        {
            await _repo.UpdateAsync(note);
            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            await _repo.DeleteAsync(id);
            return RedirectToAction("Index");
        }
    }
}
