# NoteApp
Note application for the user to create new notes, update and delete
